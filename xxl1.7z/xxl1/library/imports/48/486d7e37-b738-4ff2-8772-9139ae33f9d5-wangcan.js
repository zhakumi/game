"use strict";
cc._RF.push(module, '486d743tzhP8odykTmuM/nV', 'RequestUtils');
// Script/Utils/RequestUtils.js

"use strict";

exports.__esModule = true;
exports.userInfo = userInfo;
exports.upGameintegral = upGameintegral;
exports.gameRanking = gameRanking;
exports.addGametimes = addGametimes;
exports.updateGametimes = updateGametimes;
exports.wxAuthCode = wxAuthCode;
exports.wxAuth = wxAuth;

var _ConstValue = require("../Model/ConstValue");

//登录授权
function wxAuth(code, iv, encryptedData) {
  console.log(code, iv, encryptedData);
  return new Promise(function (resolve, reject) {
    wx.request({
      url: _ConstValue.PATH + "/routine_auth",
      method: "POST",
      header: {
        'content-type': 'application/x-www-form-urlencoded'
      },
      data: {
        code: code,
        apptype: 1,
        iv: iv,
        encryptedData: encryptedData
      },
      success: function success(res) {
        console.log("用户信息", res);
        resolve(res);
      },
      fail: function fail(res) {
        console.log("获取用户数据错误：" + res);
      }
    });
  });
}

function wxAuthCode() {
  return new Promise(function (resolve, reject) {
    wx.login({
      success: function success(res) {
        if (res.code) {
          resolve(res);
        } else {
          console.log("登录失败" + res.errMsg);
        }
      }
    });
  });
} //获取用户游戏信息


function userInfo(uid) {
  return new Promise(function (resolve, reject) {
    wx.request({
      url: _ConstValue.PATH + "/userInfo",
      method: "POST",
      header: {
        'content-type': 'application/x-www-form-urlencoded'
      },
      data: {
        appid: _ConstValue.APP_ID,
        uid: uid
      },
      success: function success(res) {
        console.log("用户信息", res);
        resolve(res);
      },
      fail: function fail(res) {
        console.log("获取用户数据错误：" + res);
      }
    });
  });
} //更新游戏积分


function upGameintegral(uid, integral) {
  return new Promise(function (resolve, reject) {
    wx.request({
      url: _ConstValue.PATH + "/upGameIntegral",
      method: "POST",
      header: {
        'content-type': 'application/x-www-form-urlencoded'
      },
      data: {
        appid: _ConstValue.APP_ID,
        uid: uid,
        integral: integral
      },
      success: function success(res) {
        console.log("更新游戏积分", res);
        resolve(res);
      },
      fail: function fail(res) {
        console.log("更新游戏积分错误：" + res);
      }
    });
  });
} // 更新用户 游戏次数


function updateGametimes(uid) {
  return new Promise(function (resolve, reject) {
    wx.request({
      url: _ConstValue.PATH + "/updateGametimes",
      method: "POST",
      header: {
        'content-type': 'application/x-www-form-urlencoded'
      },
      data: {
        appid: _ConstValue.APP_ID,
        uid: uid
      },
      success: function success(res) {
        console.log("次数扣减", res);
        resolve(res);
      },
      fail: function fail(res) {
        console.log("开始游戏 扣减游戏次数失败：" + res);
      }
    });
  });
} // 增加用户 游戏次数


function addGametimes(uid) {
  return new Promise(function (resolve, reject) {
    wx.request({
      url: _ConstValue.PATH + "/addGametimes",
      method: "POST",
      header: {
        'content-type': 'application/x-www-form-urlencoded'
      },
      data: {
        appid: _ConstValue.APP_ID,
        uid: uid,
        gametimes: 1
      },
      success: function success(res) {
        console.log("次数增加", res);
        resolve(res);
      },
      fail: function fail(res) {
        console.log("增加游戏次数失败：" + res);
      }
    });
  });
} //获取排行


function gameRanking() {
  return new Promise(function (resolve, reject) {
    wx.request({
      url: _ConstValue.PATH + "/gameRanking",
      method: "POST",
      header: {
        'content-type': 'application/x-www-form-urlencoded'
      },
      data: {
        appid: _ConstValue.APP_ID,
        num: 5
      },
      success: function success(res) {
        console.log("排行获取", res);
        resolve(res);
      },
      fail: function fail(res) {
        console.log("获取排行失败失败：" + res);
      }
    });
  });
}

cc._RF.pop();