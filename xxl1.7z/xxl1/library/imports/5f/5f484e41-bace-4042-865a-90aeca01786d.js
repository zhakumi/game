"use strict";
cc._RF.push(module, '5f4845Bus5AQoZakK7KAXht', 'LoginController');
// Script/Controller/LoginController.js

"use strict";

var _Toast = _interopRequireDefault(require("../Utils/Toast"));

var _RequestUtils = require("../Utils/RequestUtils");

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }

cc.Class({
  "extends": cc.Component,
  properties: {
    loginButton: {
      type: cc.Button,
      "default": null
    },
    shartButton: {
      type: cc.Button,
      "default": null
    },
    worldSceneBGM: {
      type: cc.AudioClip,
      "default": null
    },
    wxName: {
      type: cc.Label,
      "default": null
    },
    powerShow: {
      type: cc.Label,
      "default": null
    },
    nodePh: {
      type: cc.Node,
      "default": null
    },
    nodePhValue: {
      type: cc.Prefab,
      "default": null
    },
    phButton: {
      type: cc.Button,
      "default": null
    }
  },
  onLoad: function onLoad() {
    var _this = this;

    console.log("onLoad");
    this.wxAuthCode = 0;
    this.uid = 2;
    this.power = 0;
    (0, _RequestUtils.wxAuthCode)().then(function (res) {
      _this.wxAuthCode = res.code;

      _this.wxLogin(_this.wxAuthCode);
    });
    this.gameSceneBGMAudioId = cc.audioEngine.play(this.worldSceneBGM, true, 1);
    this.nodePh.active = false;
    this.powerShow.active = false;
    this.nodePhValue.active = false;
    window.login = this;
  },
  // 分享
  onShare: function onShare() {
    var _this2 = this;

    if (cc.sys.platform === cc.sys.WECHAT_GAME) {
      wx.shareAppMessage({
        title: "大家都来参半消消乐",
        imageUrl: "https://image.baidu.com/search/detail?ct=503316480&z=undefined&tn=baiduimagedetail&ipn=d&word=%E5%A4%A7%E7%99%BD%E7%89%99%E7%89%99%E9%BD%BF%E5%9B%BE%E7%89%87&step_word=&ie=utf-8&in=&cl=2&lm=-1&st=undefined&hd=undefined&latest=undefined&copyright=undefined&cs=668063612,1847095016&os=1872563657,3207724429&simid=3044484461,3709176146&pn=133&rn=1&di=7117150749552803841&ln=1504&fr=&fmq=1663514332010_R&fm=&ic=undefined&s=undefined&se=&sme=&tab=0&width=undefined&height=undefined&face=undefined&is=0,0&istype=0&ist=&jit=&bdtype=0&spn=0&pi=0&gsm=5a&objurl=https%3A%2F%2Fgimg2.baidu.com%2Fimage_search%2Fsrc%3Dhttp%253A%252F%252Fdpic.tiankong.com%252Fvd%252F51%252FQJ8155259097.jpg%253Fx-oss-process%253Dstyle%252Fshows%26refer%3Dhttp%253A%252F%252Fdpic.tiankong.com%26app%3D2002%26size%3Df9999%2C10000%26q%3Da80%26n%3D0%26g%3D0n%26fmt%3Dauto%3Fsec%3D1666106333%26t%3D53a13e49311b40089a6f7d40fb6bdfb3&rpstart=0&rpnum=0&adpicid=0&nojc=undefined&dyTabStr=MCwzLDIsMSw2LDQsNSw3LDgsOQ%3D%3D",
        success: function success(res) {
          console.log("share success");
        },
        fail: function fail(res) {
          console.log("share error", res);
        }
      });
      (0, _RequestUtils.addGametimes)(this.uid).then(function (res) {
        _this2.getPower();
      });
    }
  },
  wxLogin: function wxLogin(code) {
    var _this3 = this;

    if (cc.sys.platform === cc.sys.WECHAT_GAME) {
      wx.getSetting({
        success: function success(res) {
          if (!res.authSetting['scope.userInfo']) {
            _this3.showAuth(code);
          } else {
            _this3.getUser(code);
          }
        }
      });
    }
  },
  //获取用户点数
  getPower: function getPower() {
    var _this4 = this;

    (0, _RequestUtils.userInfo)(this.uid).then(function (res) {
      console.log("cb user", res.data.data);
      _this4.power = 0;

      if (res.data.data != undefined) {
        _this4.power = res.data.data[0].game_life;
      }

      _this4.powerShow.string = _this4.uid + "剩余次数：" + _this4.power + "次";
    });
  },
  //获取微信用户信息，并登陆
  getUser: function getUser(code) {
    var self = this;
    wx.getUserInfo({
      success: function success(res) {
        console.log("wx user", res);
        (0, _RequestUtils.wxAuth)(code, res.iv, res.encryptedData).then(function (res) {
          var user = res.data.data.userInfo;
          console.log(user);
          self.uid = user.uid;
          self.power = 0;

          if (res.data.data != undefined) {
            self.power = user.game_life;
          }

          self.powerShow.string = self.uid + "剩余次数：" + self.power + "次";
        });
      }
    });
  },
  showAuth: function showAuth(code) {
    var _this5 = this;

    var button = wx.createUserInfoButton({
      type: "text",
      text: " ",
      style: {
        left: 0,
        top: 0,
        right: 0,
        bottom: 0,
        width: "1334",
        height: "720",
        lineHeight: 50,
        backgroundColor: "#f00",
        color: "#ffffff",
        textAlign: "center",
        fontSize: 16,
        borderRadius: 4
      }
    });
    button.show(); //按钮点击事件

    button.onTap(function (res) {
      if (res.userInfo) {
        console.log("showAuth", res);
        button.hide();
        button.destroy();

        _this5.getUser(code);
      }
    });
  },
  wxAuth: function wxAuth() {
    wx.login({
      success: function success(res) {
        if (res.code) {
          this.wxAuthCode = res.code;
        } else {
          console.log("wx登录失败" + res.errMsg);
        }
      }
    });
  },
  begin: function begin() {
    this.initGame();
  },
  // 增加游戏积分
  upintegral: function upintegral(total) {
    (0, _RequestUtils.upGameintegral)(this.uid, total).then(function (res) {});
  },
  initGame: function initGame() {
    var _this6 = this;

    if (this.power <= 0) {
      (0, _Toast["default"])('剩余次数不够');
      return;
    } //扣减游戏次数


    (0, _RequestUtils.updateGametimes)(this.uid).then(function (res) {
      _this6.powerShow.node.active = false;
      _this6.phButton.active = false;
      _this6.loginButton.node.active = false;
      _this6.shartButton.node.active = false;
      cc.director.preloadScene("Game", function () {
        this.loginButton.node.active = false;
        this.shartButton.node.active = false;
        cc.director.loadScene("Game");
      }.bind(_this6));
    });
  },
  showPh: function showPh() {
    this.nodePh.active = true;
    this.setPhOver();
  },
  //关闭排行
  closePh: function closePh() {
    this.nodePh.active = false;
  },
  // 设置排行数据
  setPhOver: function setPhOver() {
    var _this7 = this;

    var height = -45;
    this.arr_infor = [];
    (0, _RequestUtils.gameRanking)().then(function (res) {
      _this7.arr_infor = res.data.data; //重新排序 小到大

      _this7.compare(_this7.arr_infor);

      var nodePh = _this7.node.getChildByName('nodePH');

      for (var i = 0; i < _this7.arr_infor.length; i++) {
        var node_block = cc.instantiate(_this7.nodePhValue); //实例化 

        node_block.parent = nodePh; //添加到nodePh

        node_block.getChildByName('label_id').getComponent(cc.Label).string = i + 1;
        node_block.getChildByName('label_name').getComponent(cc.Label).string = _this7.arr_infor[i].nickname;
        node_block.getChildByName('label_score').getComponent(cc.Label).string = _this7.arr_infor[i].game_integral;
        var old_block = node_block.getPosition();
        old_block.y = 200 + i * height;
        node_block.setPosition(old_block); //设置位置
      }
    });
  },
  compare: function compare(property) {
    return function (a, b) {
      var value1 = a[property];
      var value2 = b[property];
      return value1 - value2;
    };
  },
  onDestroy: function onDestroy() {
    cc.audioEngine.stop(this.gameSceneBGMAudioId);
  }
});

cc._RF.pop();