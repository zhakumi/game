# 开心消消乐
使用cocos creator 编写的三消游戏。

# 更新记录

2018/01/20 *升级工程到`cocos creator` `v1.8.1`  
2018/07/01 增加一些音效  
2019/01/30 升级工程到`cocos creator` `v2.0.7`  

# 在线试玩
[桌面版](https://crush-desktop-1252097459.cos.ap-shanghai.myqcloud.com/index.html)  
[移动版](https://crush-mobile-1252097459.cos.ap-shanghai.myqcloud.com/index.html)

# 草图
![umlclass](https://github.com/isghost/kaixinxiaoxiaole/raw/master/readmeres/umlclass.png)
# 联系方式
810278677@qq.com
